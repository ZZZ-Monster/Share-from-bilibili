#include "GetMiProcessLoaderEntry.h"
#include "SSDTFunction.h"


// �� MmLoadSystemImage �л�ȡ��Ӧ�� MiProcessLoaderEntry ������
// ����, 32��64λ�� Win7, Win8.1 ֱ�Ӵ� MmLoadSystemImage ������ MiProcessLoaderEntry
// 32��64λ�� Win10 ��Ҫ�� MmLoadSystemImageEx ������ MiConstructLoaderEntry, �ٴ� MiConstructLoaderEntry ������ MiProcessLoaderEntry
PVOID GetFuncAddr_MiProcessLoaderEntry()
{
	NTSTATUS status = STATUS_SUCCESS;
	PVOID pMmLoadSystemImage = NULL;
	PVOID pMiConstructLoaderEntry = NULL;
	PVOID pMiProcessLoaderEntry = NULL;
	UCHAR pSpecialCode[256] = { 0 };
	ULONG ulSpecialCodeLength = 256;
	ULONG ulSearchLength = 0x1000;
	PVOID pSearchResultAddr = NULL;
	LONG lOffset = 0;
	RtlZeroMemory(pSpecialCode, ulSpecialCodeLength);

	// �� NtSetSystemInformation �л�ȡ MmLoadSystemImage ������ַ
	pMmLoadSystemImage = GetFuncAddr_MmLoadSystemImage();
	if (NULL == pMmLoadSystemImage)
	{
		return pMiProcessLoaderEntry;
	}
	DbgPrint("pMmLoadSystemImageEx[0x%p]\n", pMmLoadSystemImage);


	/*
fffff804`3e347fbe 488d5580        lea     rdx,[rbp-80h]
fffff804`3e347fc2 488bcf          mov     rcx,rdi
fffff804`3e347fc5 e83e1b0000      call    nt!MiConstructLoaderEntry (fffff804`3e349b08)
	*/	// 64 Bits
	pSpecialCode[0] = 0x48;
	pSpecialCode[1] = 0x8d;
	pSpecialCode[2] = 0x55;
	pSpecialCode[3] = 0x80;
	pSpecialCode[4] = 0x48;
	pSpecialCode[5] = 0x8b;
	pSpecialCode[6] = 0xcf;
	pSpecialCode[7] = 0xe8;
	ulSpecialCodeLength = 8;
	// ����������
	pSearchResultAddr = SearchMemory((PUCHAR)pMmLoadSystemImage, (PVOID)((PUCHAR)pMmLoadSystemImage + 0xFFFF), pSpecialCode, ulSpecialCodeLength);
	
	if (NULL == pSearchResultAddr)
	{
		return pMiProcessLoaderEntry;
	}
	lOffset = *(PLONG)pSearchResultAddr;
	pMiConstructLoaderEntry = (PVOID)((PUCHAR)pSearchResultAddr + sizeof(LONG) + lOffset);
	DbgPrint("pMiConstructLoaderEntry:%p", pMiConstructLoaderEntry);


	/*
nt!MiConstructLoaderEntry+0x43a:
fffff804`3e349f42 ba01000000      mov     edx,1
fffff804`3e349f47 488bcf          mov     rcx,rdi
fffff804`3e349f4a e8955dc2ff      call    nt!MiProcessLoaderEntry (fffff804`3df6fce4)
	*/
	// ��������
	pSpecialCode[0] = 0xba;
	pSpecialCode[1] = 0x01;
	pSpecialCode[2] = 0x00;
	pSpecialCode[3] = 0x00;
	pSpecialCode[4] = 0x00;
	pSpecialCode[5] = 0x48;
	pSpecialCode[6] = 0x8b;
	pSpecialCode[7] = 0xcf;
	pSpecialCode[8] = 0xe8;
	ulSpecialCodeLength = 9;
	//pMmLoadSystemImage = pMiConstructLoaderEntry;

	//����������
	
	pSearchResultAddr = SearchMemory((PUCHAR)pMiConstructLoaderEntry, (PVOID)((PUCHAR)pMiConstructLoaderEntry + 0xFFFF), pSpecialCode, ulSpecialCodeLength);
	if (NULL == pSearchResultAddr)
	{
		return pMiProcessLoaderEntry;
	}

	lOffset = *(PLONG)pSearchResultAddr;
	pMiProcessLoaderEntry = (PVOID)((PUCHAR)pSearchResultAddr + sizeof(LONG) + lOffset);
	DbgPrint("pMiProcessLoaderEntry:%p", pMiProcessLoaderEntry);

	return pMiProcessLoaderEntry;
}


// �� NtSetSystemInformation �л�ȡ MmLoadSystemImage ������ַ
PVOID GetFuncAddr_MmLoadSystemImage()
{
	NTSTATUS status = STATUS_SUCCESS;
	PVOID pNtSetSystemInformation = NULL;
	PVOID pMmLoadSystemImage = NULL;
	UCHAR pSpecialCode[256] = { 0 };
	ULONG ulSpecialCodeLength = 256;
	PVOID pSearchResultAddr = NULL;
	LONG lOffset = 0;
	RtlZeroMemory(pSpecialCode, ulSpecialCodeLength);

	// �� SSDT �л�ȡ NtSetSystemInformation ������ַ
	pNtSetSystemInformation = GetSSDTFunction("NtSetSystemInformation");
	if (NULL == pNtSetSystemInformation)
	{
		return pMmLoadSystemImage;
	}

	// 64 Bits
	/*
	*fffff804`3e2ac633 33d2            xor     edx,edx
	fffff804`3e2ac635 488d4c2448      lea     rcx, [rsp + 48h]
	fffff804`3e2ac63a e871b30900      call    nt!MmLoadSystemImage(fffff804`3e3479b0)
	*/
	pSpecialCode[0] = 0x33;
	pSpecialCode[1] = 0xd2;
	pSpecialCode[2] = 0x48;
	pSpecialCode[3] = 0x8d;
	pSpecialCode[4] = 0x4c;
	pSpecialCode[5] = 0x24;
	pSpecialCode[6] = 0x48;
	pSpecialCode[7] = 0xe8;
	ulSpecialCodeLength = 8;
	// ����������
	pSearchResultAddr = SearchMemory((PUCHAR)pNtSetSystemInformation, (PVOID)((PUCHAR)pNtSetSystemInformation + 0xFFFF), pSpecialCode, ulSpecialCodeLength);

	if (NULL == pSearchResultAddr)
	{
		return pMmLoadSystemImage;
	}

	lOffset = *(PLONG)pSearchResultAddr;
	pMmLoadSystemImage = (PVOID)((PUCHAR)pSearchResultAddr + sizeof(LONG) + lOffset);

	return pMmLoadSystemImage;
}

// ָ���ڴ������������ɨ��
PVOID SearchMemory(PVOID pStartAddress, PVOID pEndAddress, PUCHAR pMemoryData, ULONG ulMemoryDataSize)
{
	PVOID pAddress = NULL;
	PUCHAR i = NULL;
	ULONG m = 0;
	// ɨ���ڴ�
	for (i = (PUCHAR)pStartAddress; i < (PUCHAR)pEndAddress; i++)
	{
		// �ж�������
		for (m = 0; m < ulMemoryDataSize; m++)
		{
			if (*(PUCHAR)(i + m) != pMemoryData[m])
			{
				break;
			}
		}
		// �ж��Ƿ��ҵ�����������ĵ�ַ
		if (m >= ulMemoryDataSize)
		{
			// �ҵ�������λ��, ��ȡ���������������һ��ַ
			pAddress = (PVOID)(i + ulMemoryDataSize);
			break;
		}
	}
	return pAddress;
}