# kernel_window_hide
内核级别隐藏指定窗口

<h1 align="center">
	<img src="demo.png" alt="">
	<br>
</h1>

# 效果视频
https://v.youku.com/v_show/id_XNTg0MDU1NDQwOA==.html

# 参考项目
https://github.com/KANKOSHEV/NoScreen
